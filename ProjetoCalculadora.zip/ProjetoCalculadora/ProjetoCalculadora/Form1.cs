﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMaisMenos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão 'Mais ou Menos' recebeu um clique.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão de porcentagem recebeu um clique.");
        }

        private void btnNum0_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão com o número 0 recebeu um clique")
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão 'AC' recebeu um clique.");
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão de divisão recebeu um clique.");
        }

        private void btnNum7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão com o número 7 recebeu um clique.");
        }

        private void btnNum8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Botão com o númerto 8 recebeu um clique.");
        }
    }
}
