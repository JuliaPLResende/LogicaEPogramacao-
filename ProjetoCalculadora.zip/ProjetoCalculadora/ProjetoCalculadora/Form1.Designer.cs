﻿namespace ProjetoCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnMaisMenos = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnDivisão = new System.Windows.Forms.Button();
            this.btnNum7 = new System.Windows.Forms.Button();
            this.btnNum8 = new System.Windows.Forms.Button();
            this.btnNum9 = new System.Windows.Forms.Button();
            this.btnMultiplicação = new System.Windows.Forms.Button();
            this.btnNum4 = new System.Windows.Forms.Button();
            this.btn = new System.Windows.Forms.Button();
            this.btnNum6 = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.btnNum1 = new System.Windows.Forms.Button();
            this.btnNum2 = new System.Windows.Forms.Button();
            this.btnNum3 = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.btnNum0 = new System.Windows.Forms.Button();
            this.btnVirgula = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTexto.Location = new System.Drawing.Point(204, 129);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(4);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(354, 35);
            this.txtTexto.TabIndex = 8;
            // 
            // btnAC
            // 
            this.btnAC.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.Location = new System.Drawing.Point(204, 189);
            this.btnAC.Margin = new System.Windows.Forms.Padding(4);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(68, 46);
            this.btnAC.TabIndex = 9;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = true;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnMaisMenos
            // 
            this.btnMaisMenos.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaisMenos.Location = new System.Drawing.Point(305, 189);
            this.btnMaisMenos.Margin = new System.Windows.Forms.Padding(4);
            this.btnMaisMenos.Name = "btnMaisMenos";
            this.btnMaisMenos.Size = new System.Drawing.Size(63, 46);
            this.btnMaisMenos.TabIndex = 10;
            this.btnMaisMenos.Text = "+/-";
            this.btnMaisMenos.UseVisualStyleBackColor = true;
            this.btnMaisMenos.Click += new System.EventHandler(this.btnMaisMenos_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPorcentagem.Location = new System.Drawing.Point(406, 189);
            this.btnPorcentagem.Margin = new System.Windows.Forms.Padding(4);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(61, 46);
            this.btnPorcentagem.TabIndex = 11;
            this.btnPorcentagem.Text = "%";
            this.btnPorcentagem.UseVisualStyleBackColor = true;
            this.btnPorcentagem.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnDivisão
            // 
            this.btnDivisão.BackColor = System.Drawing.Color.SandyBrown;
            this.btnDivisão.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisão.Location = new System.Drawing.Point(502, 189);
            this.btnDivisão.Margin = new System.Windows.Forms.Padding(4);
            this.btnDivisão.Name = "btnDivisão";
            this.btnDivisão.Size = new System.Drawing.Size(56, 46);
            this.btnDivisão.TabIndex = 12;
            this.btnDivisão.Text = "÷";
            this.btnDivisão.UseVisualStyleBackColor = false;
            this.btnDivisão.Click += new System.EventHandler(this.btnDivisão_Click);
            // 
            // btnNum7
            // 
            this.btnNum7.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum7.Location = new System.Drawing.Point(204, 256);
            this.btnNum7.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum7.Name = "btnNum7";
            this.btnNum7.Size = new System.Drawing.Size(68, 46);
            this.btnNum7.TabIndex = 13;
            this.btnNum7.Text = "7";
            this.btnNum7.UseVisualStyleBackColor = false;
            this.btnNum7.Click += new System.EventHandler(this.btnNum7_Click);
            // 
            // btnNum8
            // 
            this.btnNum8.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum8.Location = new System.Drawing.Point(305, 256);
            this.btnNum8.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum8.Name = "btnNum8";
            this.btnNum8.Size = new System.Drawing.Size(63, 46);
            this.btnNum8.TabIndex = 14;
            this.btnNum8.Text = "8";
            this.btnNum8.UseVisualStyleBackColor = false;
            this.btnNum8.Click += new System.EventHandler(this.btnNum8_Click);
            // 
            // btnNum9
            // 
            this.btnNum9.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum9.Location = new System.Drawing.Point(406, 256);
            this.btnNum9.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum9.Name = "btnNum9";
            this.btnNum9.Size = new System.Drawing.Size(61, 46);
            this.btnNum9.TabIndex = 15;
            this.btnNum9.Text = "9";
            this.btnNum9.UseVisualStyleBackColor = false;
            // 
            // btnMultiplicação
            // 
            this.btnMultiplicação.BackColor = System.Drawing.Color.SandyBrown;
            this.btnMultiplicação.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicação.Location = new System.Drawing.Point(502, 256);
            this.btnMultiplicação.Margin = new System.Windows.Forms.Padding(4);
            this.btnMultiplicação.Name = "btnMultiplicação";
            this.btnMultiplicação.Size = new System.Drawing.Size(56, 46);
            this.btnMultiplicação.TabIndex = 16;
            this.btnMultiplicação.Text = "x";
            this.btnMultiplicação.UseVisualStyleBackColor = false;
            // 
            // btnNum4
            // 
            this.btnNum4.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum4.Location = new System.Drawing.Point(204, 326);
            this.btnNum4.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum4.Name = "btnNum4";
            this.btnNum4.Size = new System.Drawing.Size(68, 46);
            this.btnNum4.TabIndex = 17;
            this.btnNum4.Text = "4";
            this.btnNum4.UseVisualStyleBackColor = false;
            // 
            // btn
            // 
            this.btn.BackColor = System.Drawing.Color.DarkKhaki;
            this.btn.Location = new System.Drawing.Point(305, 326);
            this.btn.Margin = new System.Windows.Forms.Padding(4);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(63, 46);
            this.btn.TabIndex = 18;
            this.btn.Text = "5";
            this.btn.UseVisualStyleBackColor = false;
            // 
            // btnNum6
            // 
            this.btnNum6.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum6.Location = new System.Drawing.Point(406, 326);
            this.btnNum6.Margin = new System.Windows.Forms.Padding(4);
            this.btnNum6.Name = "btnNum6";
            this.btnNum6.Size = new System.Drawing.Size(61, 46);
            this.btnNum6.TabIndex = 19;
            this.btnNum6.Text = "6";
            this.btnNum6.UseVisualStyleBackColor = false;
            // 
            // btnMenos
            // 
            this.btnMenos.BackColor = System.Drawing.Color.SandyBrown;
            this.btnMenos.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenos.Location = new System.Drawing.Point(502, 326);
            this.btnMenos.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(56, 46);
            this.btnMenos.TabIndex = 20;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(315, 750);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(112, 32);
            this.button13.TabIndex = 21;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(534, 730);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(112, 32);
            this.button14.TabIndex = 22;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(736, 701);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(112, 32);
            this.button15.TabIndex = 23;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(970, 730);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 32);
            this.button16.TabIndex = 24;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // btnNum1
            // 
            this.btnNum1.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum1.Location = new System.Drawing.Point(204, 393);
            this.btnNum1.Name = "btnNum1";
            this.btnNum1.Size = new System.Drawing.Size(68, 46);
            this.btnNum1.TabIndex = 25;
            this.btnNum1.Text = "1";
            this.btnNum1.UseVisualStyleBackColor = false;
            // 
            // btnNum2
            // 
            this.btnNum2.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum2.Location = new System.Drawing.Point(305, 393);
            this.btnNum2.Name = "btnNum2";
            this.btnNum2.Size = new System.Drawing.Size(63, 45);
            this.btnNum2.TabIndex = 26;
            this.btnNum2.Text = "2";
            this.btnNum2.UseVisualStyleBackColor = false;
            // 
            // btnNum3
            // 
            this.btnNum3.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum3.Location = new System.Drawing.Point(405, 393);
            this.btnNum3.Name = "btnNum3";
            this.btnNum3.Size = new System.Drawing.Size(61, 45);
            this.btnNum3.TabIndex = 27;
            this.btnNum3.Text = "3";
            this.btnNum3.UseVisualStyleBackColor = false;
            // 
            // btnMais
            // 
            this.btnMais.BackColor = System.Drawing.Color.SandyBrown;
            this.btnMais.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMais.Location = new System.Drawing.Point(502, 393);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(55, 45);
            this.btnMais.TabIndex = 28;
            this.btnMais.Text = "+";
            this.btnMais.UseCompatibleTextRendering = true;
            this.btnMais.UseVisualStyleBackColor = false;
            // 
            // btnNum0
            // 
            this.btnNum0.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnNum0.Location = new System.Drawing.Point(204, 463);
            this.btnNum0.Name = "btnNum0";
            this.btnNum0.Size = new System.Drawing.Size(164, 45);
            this.btnNum0.TabIndex = 29;
            this.btnNum0.Text = "0";
            this.btnNum0.UseVisualStyleBackColor = false;
            this.btnNum0.Click += new System.EventHandler(this.btnNum0_Click);
            // 
            // btnVirgula
            // 
            this.btnVirgula.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnVirgula.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVirgula.Location = new System.Drawing.Point(406, 463);
            this.btnVirgula.Name = "btnVirgula";
            this.btnVirgula.Size = new System.Drawing.Size(60, 45);
            this.btnVirgula.TabIndex = 30;
            this.btnVirgula.Text = ",";
            this.btnVirgula.UseVisualStyleBackColor = false;
            // 
            // btnIgual
            // 
            this.btnIgual.BackColor = System.Drawing.Color.SandyBrown;
            this.btnIgual.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIgual.Location = new System.Drawing.Point(502, 463);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(56, 45);
            this.btnIgual.TabIndex = 31;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(937, 596);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnVirgula);
            this.Controls.Add(this.btnNum0);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.btnNum3);
            this.Controls.Add(this.btnNum2);
            this.Controls.Add(this.btnNum1);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnNum6);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.btnNum4);
            this.Controls.Add(this.btnMultiplicação);
            this.Controls.Add(this.btnNum9);
            this.Controls.Add(this.btnNum8);
            this.Controls.Add(this.btnNum7);
            this.Controls.Add(this.btnDivisão);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMaisMenos);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.txtTexto);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnMaisMenos;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnDivisão;
        private System.Windows.Forms.Button btnNum7;
        private System.Windows.Forms.Button btnNum8;
        private System.Windows.Forms.Button btnNum9;
        private System.Windows.Forms.Button btnMultiplicação;
        private System.Windows.Forms.Button btnNum4;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button btnNum6;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button btnNum1;
        private System.Windows.Forms.Button btnNum2;
        private System.Windows.Forms.Button btnNum3;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnNum0;
        private System.Windows.Forms.Button btnVirgula;
        private System.Windows.Forms.Button btnIgual;
    }
}

