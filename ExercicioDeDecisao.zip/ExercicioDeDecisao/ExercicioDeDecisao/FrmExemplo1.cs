﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExercicioDeDecisao
{
    public partial class FrmExemplo1 : Form
    {
        public FrmExemplo1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FrmExemplo1_Load(object sender, EventArgs e)
        {

        }

        private void formulárioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exemplo1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo1 frmExemplo1 = new FrmExemplo1(); //Criando um objeto do tipo Frmexemplo1
            frmExemplo1.Show(); //Mostrar novo formulário exemplo1
            this.Hide(); //Esconder o que estava aberto
        }

        private void exemplo2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo2 frmExemplo2 = new FrmExemplo2(); //Criando um objeto do tipo Frmexemplo1
            frmExemplo2.Show(); //Mostrar novo formulário exemplo1
            this.Hide(); //Esconder o que estava aberto
        }

        private void exempplo3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmExemplo3 frmExemplo3 = new FrmExemplo3(); //Criando um objeto do tipo Frmexemplo1
            frmExemplo3.Show(); //Mostrar novo formulário exemplo1
            this.Hide(); //Esconder o que estava aberto
        }
    }
}
